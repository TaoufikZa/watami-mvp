var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
var import_express = __toESM(require("express"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_supabase_js = require("@supabase/supabase-js");
var import_serverless_http = __toESM(require("serverless-http"), 1);
import_dotenv.default.config();
const app = (0, import_express.default)();
const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY;
const supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey);
app.use((0, import_cors.default)());
app.use(import_express.default.json());
const router = import_express.default.Router();
router.get("/merchants", async (req, res) => {
  const { data, error } = await supabase.from("merchants").select("*");
  if (error) return res.status(500).json(error);
  res.json(data);
});
router.get("/products/:merchantId", async (req, res) => {
  const { data, error } = await supabase.from("products").select("*").eq("merchant_id", req.params.merchantId);
  if (error) return res.status(500).json(error);
  res.json(data);
});
router.get("/orders", async (req, res) => {
  const { merchantId } = req.query;
  let query = supabase.from("orders").select("*").order("created_at", { ascending: false });
  if (merchantId && merchantId !== "all") {
    query = query.eq("merchant_id", merchantId);
  }
  const { data, error } = await query;
  if (error) return res.status(500).json(error);
  res.json(data);
});
router.post("/orders", async (req, res) => {
  const { data, error } = await supabase.from("orders").insert([req.body]).select();
  if (error) return res.status(500).json(error);
  res.status(201).json(data[0]);
});
router.patch("/orders/:id", async (req, res) => {
  const { data, error } = await supabase.from("orders").update(req.body).eq("id", req.params.id).select();
  if (error) return res.status(500).json(error);
  res.json(data[0]);
});
router.get("/messages", async (req, res) => {
  const { data, error } = await supabase.from("wa_messages").select("*").order("timestamp", { ascending: true });
  if (error) return res.status(500).json(error);
  res.json(data);
});
router.post("/messages", async (req, res) => {
  const { data, error } = await supabase.from("wa_messages").insert([req.body]).select();
  if (error) return res.status(500).json(error);
  res.status(201).json(data[0]);
});
router.post("/whatsapp/webhook", async (req, res) => {
  const { event, data } = req.body;
  if (event === "MESSAGES_UPSERT") {
    const message = data.message;
    const text = message.conversation || message.extendedTextMessage?.text || "";
    const sender = data.key.remoteJid;
    if (text.toUpperCase().includes("CONFIRM_ORDER_")) {
      const orderId = text.split("CONFIRM_ORDER_")[1]?.trim();
      const { error: orderError } = await supabase.from("orders").update({
        status: "PENDING_MERCHANT_CONFIRMATION",
        user_phone: sender,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }).eq("id", orderId);
      if (!orderError) {
        await supabase.from("wa_messages").insert([{
          text: `\u2705 Order #${orderId} confirmed via real WhatsApp!`,
          sender: "bot",
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        }]);
      }
    }
  }
  res.sendStatus(200);
});
app.use("/.netlify/functions/api", router);
const handler = (0, import_serverless_http.default)(app);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
